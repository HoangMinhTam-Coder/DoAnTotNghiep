package com.karlmathuthu.taskify.taskify

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
