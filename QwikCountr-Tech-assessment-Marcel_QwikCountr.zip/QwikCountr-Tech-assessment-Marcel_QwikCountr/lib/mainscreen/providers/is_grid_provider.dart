
import '../../app.dart';

final isGridViewProvider = StateProvider<bool>((ref) {
  return true;
});
