const demoLogo = 'assets/logo.png';
