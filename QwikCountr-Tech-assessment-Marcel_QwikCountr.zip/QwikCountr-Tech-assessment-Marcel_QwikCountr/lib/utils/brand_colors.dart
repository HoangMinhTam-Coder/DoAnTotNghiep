import 'package:flutter/cupertino.dart';

class BrandColors {
  static const Color colorPrimaryLight = Color(0xFF91E4F9);
  static const Color colorError = Color.fromARGB(255, 240, 51, 60);
  static const Color colorGreen = Color(0xFFB7F397);
}
