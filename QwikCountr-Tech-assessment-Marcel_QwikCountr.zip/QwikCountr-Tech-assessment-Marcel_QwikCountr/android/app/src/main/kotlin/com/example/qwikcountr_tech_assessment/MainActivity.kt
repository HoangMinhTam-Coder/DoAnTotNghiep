package com.example.qwikcountr_tech_assessment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
